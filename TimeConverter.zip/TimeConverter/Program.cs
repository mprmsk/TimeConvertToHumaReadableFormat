﻿using System;
using TimeConverter.Service;

namespace TimeConverter
{
    /// <summary>
    /// Program to convert time to human readbale format
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Final output parameter to return
        /// </summary>
        private static string timeToWord = string.Empty;
        static void Main(string[] args)
        {
            try
            {
                int hour, minute = 0;
                // If there is no Command line arguments then it will consider current Time
                string enteredTime = args.Length > 0 ? args[0] : DateTime.Now.ToString("HH:mm");

                // split the arguments and assign into local variables
                hour = Convert.ToInt32(enteredTime.Split(':')[0]);
                minute = Convert.ToInt32(enteredTime.Split(':')[1]);

                //create object of the class
                ITimeConverter timeConverter = new TimeConverterBO();

                // pass the parameters to  convert into readbale word format
                timeToWord = timeConverter.GetTimeInHumanFormat(hour, minute);
                Console.WriteLine("Time In Human Readable Format -> " + timeToWord);
            }
            catch
            {
                Console.WriteLine("Time Format Should Be In HH:MM, Please Correct And Pass Again..!");
            }
            Console.ReadKey();
        }
    }
}
